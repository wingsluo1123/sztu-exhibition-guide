#!/usr/bin/env python3
import math
import numpy as np
import struct

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    qos_profile_sensor_data,
    QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
)
from sensor_msgs.msg import PointCloud2, PointField


def rpy_to_R(roll, pitch, yaw):
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    Rz = np.array([[cy, -sy, 0],
                   [sy,  cy, 0],
                   [ 0,   0, 1]], dtype=np.float64)
    Ry = np.array([[ cp, 0, sp],
                   [  0, 1,  0],
                   [-sp, 0, cp]], dtype=np.float64)
    Rx = np.array([[1,  0,   0],
                   [0, cr, -sr],
                   [0, sr,  cr]], dtype=np.float64)
    return (Rz @ Ry @ Rx)


def make_pointfield(name, offset, datatype, count=1):
    f = PointField()
    f.name = name
    f.offset = offset
    f.datatype = datatype
    f.count = count
    return f


class PclRectifier(Node):
    def __init__(self):
        super().__init__("pcl_rectifier")

        # ===== 你只改这里（固定配置，无需终端参数）=====
        self.input_topic  = "/aima/hal/sensor/lidar_chest_front/lidar_pointcloud"
        self.output_topic = "/lidar/points_rectified"
        self.output_frame = "lidar_rectified"

        # 点云扶正（按你之前选好的）
        self.roll_deg  = -90.0
        self.pitch_deg = 0.0
        self.yaw_deg   = 0.0

        # timestamp 单位：你的 span≈9.48e7 对应 0.0948s → 强烈像 ns
        self.timestamp_scale = 1e-9   # raw timestamp * 1e-9 = seconds
        # =================================================

        for key, value in [('input_topic', self.input_topic), ('output_topic', self.output_topic),
                           ('output_frame', self.output_frame), ('roll_deg', self.roll_deg),
                           ('pitch_deg', self.pitch_deg), ('yaw_deg', self.yaw_deg)]:
            setattr(self, key, self.declare_parameter(key, value).value)
        self.R = rpy_to_R(math.radians(self.roll_deg),
                          math.radians(self.pitch_deg),
                          math.radians(self.yaw_deg))
                          
        # ✅ 输入：匹配传感器（BEST_EFFORT）
        qos_in = qos_profile_sensor_data
        if self.declare_parameter('reliable_input', False).value:
            qos_in = QoSProfile(depth=100, reliability=ReliabilityPolicy.RELIABLE)

        # ✅ 输出：给下游用（RELIABLE）
        qos_out = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE
        )
                         

        self.pub = self.create_publisher(PointCloud2, self.output_topic, qos_out)
        self.sub = self.create_subscription(PointCloud2, self.input_topic, self.cb, qos_in)
        
        self.get_logger().info(f"Rectifier started: {self.input_topic} -> {self.output_topic}")
        self.get_logger().info(f"RPY(deg): {self.roll_deg}, {self.pitch_deg}, {self.yaw_deg}")
        self.get_logger().info(f"timestamp_scale={self.timestamp_scale} (raw->sec), output adds field 'time' (float32, rel)")

    def cb(self, msg: PointCloud2):
        # Preserve arbitrary original fields and row padding; only xyz and time change.
        from copy import deepcopy
        fields = {f.name: f for f in msg.fields}
        if any(k not in fields for k in ['x', 'y', 'z', 'timestamp']):
            self.get_logger().error('Missing xyz/timestamp field')
            return
        if any(fields[k].datatype != PointField.FLOAT32 for k in ['x', 'y', 'z']) or fields['timestamp'].datatype != PointField.FLOAT64:
            self.get_logger().error('Unsupported xyz/timestamp datatype')
            return
        if 'time' in fields:
            self.get_logger().error('Input already has time; refusing double rectification')
            return
        endian = '>' if msg.is_bigendian else '<'
        dtype = np.dtype({'names': ['x', 'y', 'z', 'timestamp'],
                          'formats': [endian+'f4']*3+[endian+'f8'],
                          'offsets': [fields[k].offset for k in ['x', 'y', 'z', 'timestamp']],
                          'itemsize': msg.point_step})
        raw = np.ndarray((msg.height, msg.width), dtype=dtype, buffer=msg.data,
                         strides=(msg.row_step, msg.point_step))
        xyz = np.stack([raw[k].reshape(-1) for k in ['x', 'y', 'z']], axis=1)
        times = raw['timestamp'].reshape(-1)
        if len(times) == 0 or not np.isfinite(times).all() or times.min() < 0:
            self.get_logger().error('Invalid point timestamps')
            return
        t0 = float(times.min())
        step = msg.point_step + 4
        output = bytearray(len(times)*step)
        byte_rows = np.ndarray((msg.height, msg.width, msg.point_step), dtype='u1',
                               buffer=msg.data, strides=(msg.row_step, msg.point_step, 1))
        np.ndarray((len(times), step), dtype='u1', buffer=output)[:, :msg.point_step] = byte_rows.reshape(-1, msg.point_step)
        transformed = xyz @ self.R.T
        for i, k in enumerate(['x', 'y', 'z']):
            np.ndarray((len(times),), dtype=endian+'f4', buffer=output,
                       offset=fields[k].offset, strides=(step,))[:] = transformed[:, i]
        np.ndarray((len(times),), dtype=endian+'f4', buffer=output,
                   offset=msg.point_step, strides=(step,))[:] = (times-t0)*self.timestamp_scale
        out = PointCloud2()
        out.header = deepcopy(msg.header)
        # timestamp is a nanosecond offset from the raw frame header in these bags.
        # Moving t0 into the header preserves each point's absolute acquisition time.
        start_ns = msg.header.stamp.sec*1_000_000_000 + msg.header.stamp.nanosec + round(t0*self.timestamp_scale*1e9)
        out.header.stamp.sec, out.header.stamp.nanosec = divmod(start_ns, 1_000_000_000)
        out.header.frame_id = self.output_frame
        out.height, out.width = msg.height, msg.width
        out.fields = list(msg.fields) + [make_pointfield('time', msg.point_step, PointField.FLOAT32)]
        out.is_bigendian, out.is_dense = msg.is_bigendian, msg.is_dense
        out.point_step, out.row_step = step, step*msg.width
        out.data = bytes(output)
        self.pub.publish(out)


def main():
    rclpy.init()
    node = PclRectifier()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
