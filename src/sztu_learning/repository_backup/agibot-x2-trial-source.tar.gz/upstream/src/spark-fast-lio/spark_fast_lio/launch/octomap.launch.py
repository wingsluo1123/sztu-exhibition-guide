<!--
  Example launch file for octomap_server mapping:
  Listens to incoming PointCloud2 data and incrementally builds an octomap.
  The data is sent out in different representations.

  Copy this file into your workspace and adjust as needed, see
  www.ros.org/wiki/octomap_server for details
-->
<launch>
	<node pkg="octomap_server" exec="octomap_server_node" name="octomap_server">
		<param name="resolution" value="0.1"/>

		<!--  fixed map frame (set to 'map' if SLAM or localization running!)  -->
		<param name="frame_id" value="map"/>

		<!--  maximum range to integrate (speedup!)  -->
		<param name="sensor_model.max_range" value="20.0"/>
		<param name="incremental_2D_projection" value="false"/>
		<param name="occupancy_min_z" value="-0.5"/>
		<param name="occupancy_max_z" value="0.5"/>

		<!-- ground filtering -->
		<param name="filter_ground_plane" value="true"/>
		<param name="ground_filter.distance" value="0.04"/>
		<param name="ground_filter.angle" value="0.15"/>
		<param name="ground_filter.plane_distance" value="1.00"/>
		<param name="pointcloud_min_z" value="-0.5"/>
		<param name="pointcloud_max_z" value="0.5"/>

		<!--  data source to integrate (PointCloud2)  -->
		<remap from="cloud_in" to="/map"/>
	</node>
</launch>
